# AI Buddy 🤖

AI Buddy का पहला Demo Version — एक simple Hindi/English chat interface.

## चलाने का तरीका

1. इस folder को डाउनलोड/Extract करें।
2. `index.html` को Chrome में खोलें।
3. अपना message लिखकर **भेजें** दबाएँ।

> यह version Demo Mode में है। इसमें कोई API key नहीं है।

## अगला Version

असली AI जवाबों के लिए एक सुरक्षित backend और AI API जोड़ें। API key को कभी भी `script.js` या public GitHub repository में न रखें।
