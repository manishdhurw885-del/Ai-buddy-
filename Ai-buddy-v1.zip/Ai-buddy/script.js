const chat=document.getElementById("chat");
const form=document.getElementById("chatForm");
const input=document.getElementById("userInput");
const typing=document.getElementById("typing");

function addMessage(text,type){
  const div=document.createElement("div");
  div.className="message "+type;
  div.textContent=text;
  chat.appendChild(div);
  chat.scrollTop=chat.scrollHeight;
}

function demoReply(text){
  const t=text.toLowerCase();
  if(t.includes("hello")||t.includes("hi")||t.includes("नमस्ते"))
    return "नमस्ते! 😊 मैं AI Buddy हूँ। आज मैं आपकी कैसे मदद करूँ?";
  if(t.includes("नाम"))
    return "मेरा नाम AI Buddy है। 🤖";
  if(t.includes("समय"))
    return "आपके डिवाइस के अनुसार अभी समय "+new Date().toLocaleTimeString("hi-IN")+" है।";
  if(t.includes("धन्यवाद")||t.includes("thanks"))
    return "आपका स्वागत है! 😊";
  return "मैं अभी Demo Mode में हूँ। आपका संदेश मिला: “"+text+"”\n\nअगले version में हम असली AI API जोड़ सकते हैं ताकि मैं आपके सवालों के जवाब दे सकूँ।";
}

form.addEventListener("submit",(e)=>{
  e.preventDefault();
  const text=input.value.trim();
  if(!text)return;
  addMessage(text,"user");
  input.value="";
  typing.style.display="block";
  setTimeout(()=>{
    typing.style.display="none";
    addMessage(demoReply(text),"bot");
  },600);
});
